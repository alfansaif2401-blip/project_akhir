<?php
session_start();

// ==================== KONFIGURASI & DATA ====================
// Database pengguna dengan role berbeda
$users = [
    'admin' => ['password' => 'admin123', 'role' => 'admin', 'name' => 'Administrator'],
    'staff' => ['password' => 'staff123', 'role' => 'staff', 'name' => 'Staff'],
    'manager' => ['password' => 'manager123', 'role' => 'manager', 'name' => 'Manager']
];

// Inisialisasi data inventaris jika belum ada
if (!isset($_SESSION['inventory'])) {
    $_SESSION['inventory'] = [
        1 => ['id' => 1, 'kode' => 'INV001', 'nama' => 'Laptop Dell XPS 15', 'kategori' => 'Elektronik', 'jumlah' => 10, 'harga' => 25000000, 'lokasi' => 'Gudang A', 'status' => 'Tersedia', 'created_by' => 'admin', 'created_at' => '2024-01-15'],
        2 => ['id' => 2, 'kode' => 'INV002', 'nama' => 'Meja Kantor Kayu Jati', 'kategori' => 'Furniture', 'jumlah' => 25, 'harga' => 3500000, 'lokasi' => 'Gudang B', 'status' => 'Tersedia', 'created_by' => 'admin', 'created_at' => '2024-01-16'],
        3 => ['id' => 3, 'kode' => 'INV003', 'nama' => 'Printer HP LaserJet Pro', 'kategori' => 'Elektronik', 'jumlah' => 15, 'harga' => 4500000, 'lokasi' => 'Gudang A', 'status' => 'Tersedia', 'created_by' => 'staff', 'created_at' => '2024-01-17'],
        4 => ['id' => 4, 'kode' => 'INV004', 'nama' => 'Kursi Ergonomis Executive', 'kategori' => 'Furniture', 'jumlah' => 30, 'harga' => 2500000, 'lokasi' => 'Gudang B', 'status' => 'Tersedia', 'created_by' => 'manager', 'created_at' => '2024-01-18'],
        5 => ['id' => 5, 'kode' => 'INV005', 'nama' => 'Monitor LG 27 inch', 'kategori' => 'Elektronik', 'jumlah' => 20, 'harga' => 3200000, 'lokasi' => 'Gudang A', 'status' => 'Tersedia', 'created_by' => 'admin', 'created_at' => '2024-01-19'],
    ];
}

// ==================== HANDLER AKSI ====================
$action = $_GET['action'] ?? 'dashboard';
$message = '';

// Login Handler
if (isset($_POST['login'])) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (isset($users[$username]) && $users[$username]['password'] === $password) {
        $_SESSION['logged_in'] = true;
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $users[$username]['role'];
        $_SESSION['name'] = $users[$username]['name'];
        header('Location: ?action=dashboard');
        exit;
    } else {
        $message = '<div class="alert alert-danger">Username atau password salah!</div>';
    }
}

// Logout Handler
if ($action === 'logout') {
    session_destroy();
    header('Location: ?action=login');
    exit;
}

// CRUD Handlers
if (isset($_SESSION['logged_in'])) {
    $role = $_SESSION['role'];
    
    // CREATE
    if ($action === 'create' && isset($_POST['submit_create'])) {
        $new_id = max(array_keys($_SESSION['inventory'])) + 1;
        $_SESSION['inventory'][$new_id] = [
            'id' => $new_id,
            'kode' => $_POST['kode'],
            'nama' => $_POST['nama'],
            'kategori' => $_POST['kategori'],
            'jumlah' => (int)$_POST['jumlah'],
            'harga' => (int)$_POST['harga'],
            'lokasi' => $_POST['lokasi'],
            'status' => $_POST['status'],
            'created_by' => $_SESSION['username'],
            'created_at' => date('Y-m-d')
        ];
        $message = '<div class="alert alert-success">Data berhasil ditambahkan!</div>';
    }
    
    // UPDATE
    if ($action === 'update' && isset($_POST['submit_update'])) {
        $id = (int)$_POST['id'];
        if (isset($_SESSION['inventory'][$id])) {
            $_SESSION['inventory'][$id]['kode'] = $_POST['kode'];
            $_SESSION['inventory'][$id]['nama'] = $_POST['nama'];
            $_SESSION['inventory'][$id]['kategori'] = $_POST['kategori'];
            $_SESSION['inventory'][$id]['jumlah'] = (int)$_POST['jumlah'];
            $_SESSION['inventory'][$id]['harga'] = (int)$_POST['harga'];
            $_SESSION['inventory'][$id]['lokasi'] = $_POST['lokasi'];
            $_SESSION['inventory'][$id]['status'] = $_POST['status'];
            $message = '<div class="alert alert-success">Data berhasil diperbarui!</div>';
        }
    }
    
    // DELETE
    if ($action === 'delete' && isset($_GET['id']) && $role === 'admin') {
        $id = (int)$_GET['id'];
        if (isset($_SESSION['inventory'][$id])) {
            unset($_SESSION['inventory'][$id]);
            $message = '<div class="alert alert-success">Data berhasil dihapus!</div>';
        }
    }
}

// Redirect ke login jika belum login
if (!isset($_SESSION['logged_in']) && $action !== 'login') {
    header('Location: ?action=login');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventaris App - Sistem Manajemen Inventaris Profesional</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        /* ==================== LOGIN PAGE ==================== */
        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .login-box {
            background: white;
            padding: 50px 40px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 450px;
            animation: fadeIn 0.5s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .login-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .login-logo i {
            font-size: 60px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 15px;
        }
        
        .login-logo h1 {
            font-size: 28px;
            color: #2d3748;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .login-logo p {
            color: #718096;
            font-size: 14px;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #4a5568;
            font-weight: 500;
            font-size: 14px;
        }
        
        .form-group input {
            width: 100%;
            padding: 14px 18px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s;
            font-family: 'Inter', sans-serif;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .btn-login {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
        
        .login-info {
            margin-top: 30px;
            padding: 20px;
            background: #f7fafc;
            border-radius: 10px;
            border-left: 4px solid #667eea;
        }
        
        .login-info h3 {
            font-size: 14px;
            color: #2d3748;
            margin-bottom: 10px;
            font-weight: 600;
        }
        
        .login-info ul {
            list-style: none;
            font-size: 13px;
            color: #4a5568;
        }
        
        .login-info li {
            margin: 5px 0;
        }
        
        .login-info strong {
            color: #667eea;
        }
        
        /* ==================== DASHBOARD LAYOUT ==================== */
        .dashboard-wrapper {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #2d3748 0%, #1a202c 100%);
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
        
        .sidebar-header {
            padding: 30px 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-header h2 {
            font-size: 24px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .sidebar-header h2 i {
            font-size: 28px;
            color: #667eea;
        }
        
        .sidebar-header p {
            font-size: 13px;
            color: #a0aec0;
            margin-top: 5px;
        }
        
        .user-info {
            padding: 20px 25px;
            background: rgba(102, 126, 234, 0.1);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .user-info .user-avatar {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            margin-bottom: 12px;
        }
        
        .user-info h3 {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 3px;
        }
        
        .user-info p {
            font-size: 13px;
            color: #a0aec0;
        }
        
        .user-badge {
            display: inline-block;
            padding: 4px 12px;
            background: rgba(102, 126, 234, 0.2);
            border-radius: 20px;
            font-size: 11px;
            margin-top: 8px;
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        
        .sidebar-menu {
            padding: 25px 0;
        }
        
        .menu-title {
            padding: 0 25px;
            font-size: 11px;
            color: #a0aec0;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 15px;
            font-weight: 600;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 14px 25px;
            color: #cbd5e0;
            text-decoration: none;
            transition: all 0.3s;
            gap: 15px;
            font-size: 14px;
        }
        
        .sidebar-menu a i {
            font-size: 18px;
            width: 20px;
            text-align: center;
        }
        
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(102, 126, 234, 0.15);
            color: white;
            border-left: 3px solid #667eea;
        }
        
        .main-content {
            margin-left: 280px;
            flex: 1;
            background: #f7fafc;
        }
        
        .top-navbar {
            background: white;
            padding: 20px 40px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 999;
        }
        
        .navbar-left h1 {
            font-size: 24px;
            color: #2d3748;
            font-weight: 700;
        }
        
        .navbar-left p {
            font-size: 14px;
            color: #718096;
            margin-top: 3px;
        }
        
        .navbar-right {
            display: flex;
            gap: 15px;
            align-items: center;
        }
        
        .navbar-btn {
            padding: 10px 20px;
            background: #f7fafc;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            color: #4a5568;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .navbar-btn:hover {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        
        .navbar-btn.btn-danger {
            background: #fc8181;
            border-color: #fc8181;
            color: white;
        }
        
        .navbar-btn.btn-danger:hover {
            background: #f56565;
        }
        
        .content-area {
            padding: 40px;
        }
        
        /* ==================== STATS CARDS ==================== */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }
        
        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }
        
        .stat-icon {
            width: 55px;
            height: 55px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }
        
        .stat-icon.purple { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .stat-icon.blue { background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%); }
        .stat-icon.green { background: linear-gradient(135deg, #48bb78 0%, #38a169 100%); }
        .stat-icon.orange { background: linear-gradient(135deg, #ed8936 0%, #dd6b20 100%); }
        
        .stat-value {
            font-size: 32px;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 14px;
            color: #718096;
            font-weight: 500;
        }
        
        /* ==================== TABLE ==================== */
        .data-table-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }
        
        .table-header {
            padding: 25px 30px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .table-header h2 {
            font-size: 20px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .btn-add {
            padding: 10px 25px;
            background: white;
            color: #667eea;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
        }
        
        .btn-add:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background: #f7fafc;
        }
        
        thead th {
            padding: 18px 20px;
            text-align: left;
            font-size: 13px;
            font-weight: 600;
            color: #4a5568;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid #e2e8f0;
        }
        
        tbody td {
            padding: 18px 20px;
            color: #2d3748;
            border-bottom: 1px solid #e2e8f0;
            font-size: 14px;
        }
        
        tbody tr {
            transition: background 0.2s;
        }
        
        tbody tr:hover {
            background: #f7fafc;
        }
        
        .badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-success { background: #c6f6d5; color: #22543d; }
        .badge-warning { background: #feebc8; color: #7c2d12; }
        .badge-danger { background: #fed7d7; color: #742a2a; }
        
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        
        .btn-action {
            padding: 8px 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 500;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        
        .btn-edit {
            background: #bee3f8;
            color: #2c5282;
        }
        
        .btn-edit:hover {
            background: #90cdf4;
        }
        
        .btn-delete {
            background: #fed7d7;
            color: #742a2a;
        }
        
        .btn-delete:hover {
            background: #fc8181;
            color: white;
        }
        
        .btn-view {
            background: #c6f6d5;
            color: #22543d;
        }
        
        .btn-view:hover {
            background: #9ae6b4;
        }
        
        /* ==================== FORMS ==================== */
        .form-container {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            max-width: 900px;
        }
        
        .form-title {
            font-size: 24px;
            color: #2d3748;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e2e8f0;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
        }
        
        .form-grid .form-group {
            margin-bottom: 0;
        }
        
        .form-group.full-width {
            grid-column: 1 / -1;
        }
        
        .form-group select,
        .form-group input[type="text"],
        .form-group input[type="number"] {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
            font-family: 'Inter', sans-serif;
        }
        
        .form-group select:focus,
        .form-group input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .form-actions {
            margin-top: 30px;
            display: flex;
            gap: 15px;
            padding-top: 25px;
            border-top: 2px solid #e2e8f0;
        }
        
        .btn-submit {
            padding: 12px 30px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        
        .btn-cancel {
            padding: 12px 30px;
            background: #f7fafc;
            color: #4a5568;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
        }
        
        .btn-cancel:hover {
            background: #e2e8f0;
        }
        
        /* ==================== ALERTS ==================== */
        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            font-size: 14px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-success {
            background: #c6f6d5;
            color: #22543d;
            border-left: 4px solid #38a169;
        }
        
        .alert-danger {
            background: #fed7d7;
            color: #742a2a;
            border-left: 4px solid #e53e3e;
        }
        
        .alert i {
            font-size: 18px;
        }
        
        /* ==================== RESPONSIVE ==================== */
        @media (max-width: 768px) {
            .sidebar {
                width: 0;
                display: none;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .top-navbar {
                padding: 15px 20px;
            }
            
            .content-area {
                padding: 20px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .table-responsive {
                font-size: 12px;
            }
        }
    </style>
</head>
<body>

<?php if ($action === 'login'): ?>
    <!-- ==================== LOGIN PAGE ==================== -->
    <div class="login-container">
        <div class="login-box">
            <div class="login-logo">
                <i class="fas fa-boxes-stacked"></i>
                <h1>Inventaris App</h1>
                <p>Sistem Manajemen Inventaris Enterprise</p>
            </div>
            
            <?= $message ?>
            
            <form method="POST">
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Username</label>
                    <input type="text" name="username" placeholder="Masukkan username" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> Password</label>
                    <input type="password" name="password" placeholder="Masukkan password" required>
                </div>
                <button type="submit" name="login" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i> Login ke Dashboard
                </button>
            </form>
            
            <div class="login-info">
                <h3><i class="fas fa-info-circle"></i> Akun Demo</h3>
                <ul>
                    <li><strong>Admin:</strong> admin / admin123</li>
                    <li><strong>Manager:</strong> manager / manager123</li>
                    <li><strong>Staff:</strong> staff / staff123</li>
                </ul>
            </div>
        </div>
    </div>

<?php else: ?>
    <!-- ==================== DASHBOARD ==================== -->
    <div class="dashboard-wrapper">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2><i class="fas fa-boxes-stacked"></i> Inventaris App</h2>
                <p>Enterprise Management System</p>
            </div>
            
            <div class="user-info">
                <div class="user-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <h3><?= $_SESSION['name'] ?></h3>
                <p>@<?= $_SESSION['username'] ?></p>
                <span class="user-badge"><?= strtoupper($_SESSION['role']) ?></span>
            </div>
            
            <div class="sidebar-menu">
                <div class="menu-title">Menu Utama</div>
                <a href="?action=dashboard" class="<?= $action === 'dashboard' ? 'active' : '' ?>">
                    <i class="fas fa-chart-line"></i> Dashboard
                </a>
                <a href="?action=inventory" class="<?= $action === 'inventory' ? 'active' : '' ?>">
                    <i class="fas fa-boxes"></i> Data Inventaris
                </a>
                
                <?php if ($_SESSION['role'] !== 'staff'): ?>
                <a href="?action=create" class="<?= $action === 'create' ? 'active' : '' ?>">
                    <i class="fas fa-plus-circle"></i> Tambah Data
                </a>
                <?php endif; ?>
                
                <?php if ($_SESSION['role'] === 'admin'): ?>
                <div class="menu-title" style="margin-top: 20px;">Administrator</div>
                <a href="?action=reports">
                    <i class="fas fa-file-alt"></i> Laporan
                </a>
                <a href="?action=settings">
                    <i class="fas fa-cog"></i> Pengaturan
                </a>
                <?php endif; ?>
                
                <div class="menu-title" style="margin-top: 20px;">Akun</div>
                <a href="?action=logout">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navbar -->
            <div class="top-navbar">
                <div class="navbar-left">
                    <h1>
                        <?php
                        $titles = [
                            'dashboard' => 'Dashboard',
                            'inventory' => 'Data Inventaris',
                            'create' => 'Tambah Data Baru',
                            'update' => 'Edit Data',
                            'reports' => 'Laporan',
                            'settings' => 'Pengaturan'
                        ];
                        echo $titles[$action] ?? 'Dashboard';
                        ?>
                    </h1>
                    <p><?= date('l, d F Y') ?> • Selamat datang, <?= $_SESSION['name'] ?></p>
                </div>
                <div class="navbar-right">
                    <a href="?action=inventory" class="navbar-btn">
                        <i class="fas fa-boxes"></i> Inventaris
                    </a>
                    <a href="?action=logout" class="navbar-btn btn-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
            
            <!-- Content Area -->
            <div class="content-area">
                <?= $message ?>
                
                <?php if ($action === 'dashboard'): ?>
                    <!-- ==================== DASHBOARD STATS ==================== -->
                    <?php
                    $total_items = count($_SESSION['inventory']);
                    $total_quantity = array_sum(array_column($_SESSION['inventory'], 'jumlah'));
                    $total_value = array_sum(array_map(function($item) {
                        return $item['jumlah'] * $item['harga'];
                    }, $_SESSION['inventory']));
                    $categories = array_unique(array_column($_SESSION['inventory'], 'kategori'));
                    ?>
                    
                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-header">
                                <div>
                                    <div class="stat-value"><?= $total_items ?></div>
                                    <div class="stat-label">Total Item</div>
                                </div>
                                <div class="stat-icon purple">
                                    <i class="fas fa-boxes"></i>
                                </div>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-header">
                                <div>
                                    <div class="stat-value"><?= $total_quantity ?></div>
                                    <div class="stat-label">Total Stok</div>
                                </div>
                                <div class="stat-icon blue">
                                    <i class="fas fa-cubes"></i>
                                </div>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-header">
                                <div>
                                    <div class="stat-value">Rp <?= number_format($total_value/1000000, 1) ?>M</div>
                                    <div class="stat-label">Total Nilai</div>
                                </div>
                                <div class="stat-icon green">
                                    <i class="fas fa-money-bill-wave"></i>
                                </div>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-header">
                                <div>
                                    <div class="stat-value"><?= count($categories) ?></div>
                                    <div class="stat-label">Kategori</div>
                                </div>
                                <div class="stat-icon orange">
                                    <i class="fas fa-layer-group"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Recent Items Table -->
                    <div class="data-table-container">
                        <div class="table-header">
                            <h2><i class="fas fa-clock"></i> Item Terbaru</h2>
                            <a href="?action=inventory" class="btn-add">
                                <i class="fas fa-arrow-right"></i> Lihat Semua
                            </a>
                        </div>
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Kode</th>
                                        <th>Nama Item</th>
                                        <th>Kategori</th>
                                        <th>Stok</th>
                                        <th>Harga</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $recent_items = array_slice($_SESSION['inventory'], -5, 5, true);
                                    foreach (array_reverse($recent_items, true) as $item):
                                    ?>
                                    <tr>
                                        <td><strong><?= $item['kode'] ?></strong></td>
                                        <td><?= $item['nama'] ?></td>
                                        <td><?= $item['kategori'] ?></td>
                                        <td><?= $item['jumlah'] ?> unit</td>
                                        <td>Rp <?= number_format($item['harga'], 0, ',', '.') ?></td>
                                        <td>
                                            <span class="badge badge-success"><?= $item['status'] ?></span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                <?php elseif ($action === 'inventory'): ?>
                    <!-- ==================== INVENTORY LIST ==================== -->
                    <div class="data-table-container">
                        <div class="table-header">
                            <h2><i class="fas fa-database"></i> Daftar Inventaris Lengkap</h2>
                            <?php if ($_SESSION['role'] !== 'staff'): ?>
                            <a href="?action=create" class="btn-add">
                                <i class="fas fa-plus"></i> Tambah Data
                            </a>
                            <?php endif; ?>
                        </div>
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Kode</th>
                                        <th>Nama Item</th>
                                        <th>Kategori</th>
                                        <th>Stok</th>
                                        <th>Harga Satuan</th>
                                        <th>Total Nilai</th>
                                        <th>Lokasi</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($_SESSION['inventory'] as $item): ?>
                                    <tr>
                                        <td><?= $item['id'] ?></td>
                                        <td><strong><?= $item['kode'] ?></strong></td>
                                        <td><?= $item['nama'] ?></td>
                                        <td><?= $item['kategori'] ?></td>
                                        <td><?= $item['jumlah'] ?> unit</td>
                                        <td>Rp <?= number_format($item['harga'], 0, ',', '.') ?></td>
                                        <td><strong>Rp <?= number_format($item['jumlah'] * $item['harga'], 0, ',', '.') ?></strong></td>
                                        <td><?= $item['lokasi'] ?></td>
                                        <td>
                                            <span class="badge badge-success"><?= $item['status'] ?></span>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <?php if ($_SESSION['role'] !== 'staff'): ?>
                                                <a href="?action=update&id=<?= $item['id'] ?>" class="btn-action btn-edit">
                                                    <i class="fas fa-edit"></i> Edit
                                                </a>
                                                <?php endif; ?>
                                                
                                                <?php if ($_SESSION['role'] === 'admin'): ?>
                                                <a href="?action=delete&id=<?= $item['id'] ?>" 
                                                   onclick="return confirm('Yakin ingin menghapus data ini?')" 
                                                   class="btn-action btn-delete">
                                                    <i class="fas fa-trash"></i> Hapus
                                                </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                <?php elseif ($action === 'create'): ?>
                    <!-- ==================== CREATE FORM ==================== -->
                    <div class="form-container">
                        <h2 class="form-title">
                            <i class="fas fa-plus-circle"></i> Tambah Data Inventaris Baru
                        </h2>
                        <form method="POST" action="?action=create">
                            <div class="form-grid">
                                <div class="form-group">
                                    <label>Kode Item</label>
                                    <input type="text" name="kode" placeholder="INV001" required>
                                </div>
                                <div class="form-group">
                                    <label>Kategori</label>
                                    <select name="kategori" required>
                                        <option value="">Pilih Kategori</option>
                                        <option value="Elektronik">Elektronik</option>
                                        <option value="Furniture">Furniture</option>
                                        <option value="Alat Tulis">Alat Tulis</option>
                                        <option value="Perlengkapan">Perlengkapan</option>
                                    </select>
                                </div>
                                <div class="form-group full-width">
                                    <label>Nama Item</label>
                                    <input type="text" name="nama" placeholder="Masukkan nama item" required>
                                </div>
                                <div class="form-group">
                                    <label>Jumlah Stok</label>
                                    <input type="number" name="jumlah" placeholder="0" min="0" required>
                                </div>
                                <div class="form-group">
                                    <label>Harga Satuan (Rp)</label>
                                    <input type="number" name="harga" placeholder="0" min="0" required>
                                </div>
                                <div class="form-group">
                                    <label>Lokasi Penyimpanan</label>
                                    <select name="lokasi" required>
                                        <option value="">Pilih Lokasi</option>
                                        <option value="Gudang A">Gudang A</option>
                                        <option value="Gudang B">Gudang B</option>
                                        <option value="Gudang C">Gudang C</option>
                                        <option value="Ruang Penyimpanan">Ruang Penyimpanan</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Status</label>
                                    <select name="status" required>
                                        <option value="Tersedia">Tersedia</option>
                                        <option value="Habis">Habis</option>
                                        <option value="Dalam Pemesanan">Dalam Pemesanan</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-actions">
                                <button type="submit" name="submit_create" class="btn-submit">
                                    <i class="fas fa-save"></i> Simpan Data
                                </button>
                                <a href="?action=inventory" class="btn-cancel">
                                    <i class="fas fa-times"></i> Batal
                                </a>
                            </div>
                        </form>
                    </div>
                    
                <?php elseif ($action === 'update' && isset($_GET['id'])): ?>
                    <!-- ==================== UPDATE FORM ==================== -->
                    <?php
                    $id = (int)$_GET['id'];
                    $item = $_SESSION['inventory'][$id] ?? null;
                    if ($item):
                    ?>
                    <div class="form-container">
                        <h2 class="form-title">
                            <i class="fas fa-edit"></i> Edit Data Inventaris
                        </h2>
                        <form method="POST" action="?action=update">
                            <input type="hidden" name="id" value="<?= $item['id'] ?>">
                            <div class="form-grid">
                                <div class="form-group">
                                    <label>Kode Item</label>
                                    <input type="text" name="kode" value="<?= $item['kode'] ?>" required>
                                </div>
                                <div class="form-group">
                                    <label>Kategori</label>
                                    <select name="kategori" required>
                                        <option value="Elektronik" <?= $item['kategori'] === 'Elektronik' ? 'selected' : '' ?>>Elektronik</option>
                                        <option value="Furniture" <?= $item['kategori'] === 'Furniture' ? 'selected' : '' ?>>Furniture</option>
                                        <option value="Alat Tulis" <?= $item['kategori'] === 'Alat Tulis' ? 'selected' : '' ?>>Alat Tulis</option>
                                        <option value="Perlengkapan" <?= $item['kategori'] === 'Perlengkapan' ? 'selected' : '' ?>>Perlengkapan</option>
                                    </select>
                                </div>
                                <div class="form-group full-width">
                                    <label>Nama Item</label>
                                    <input type="text" name="nama" value="<?= $item['nama'] ?>" required>
                                </div>
                                <div class="form-group">
                                    <label>Jumlah Stok</label>
                                    <input type="number" name="jumlah" value="<?= $item['jumlah'] ?>" min="0" required>
                                </div>
                                <div class="form-group">
                                    <label>Harga Satuan (Rp)</label>
                                    <input type="number" name="harga" value="<?= $item['harga'] ?>" min="0" required>
                                </div>
                                <div class="form-group">
                                    <label>Lokasi Penyimpanan</label>
                                    <select name="lokasi" required>
                                        <option value="Gudang A" <?= $item['lokasi'] === 'Gudang A' ? 'selected' : '' ?>>Gudang A</option>
                                        <option value="Gudang B" <?= $item['lokasi'] === 'Gudang B' ? 'selected' : '' ?>>Gudang B</option>
                                        <option value="Gudang C" <?= $item['lokasi'] === 'Gudang C' ? 'selected' : '' ?>>Gudang C</option>
                                        <option value="Ruang Penyimpanan" <?= $item['lokasi'] === 'Ruang Penyimpanan' ? 'selected' : '' ?>>Ruang Penyimpanan</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Status</label>
                                    <select name="status" required>
                                        <option value="Tersedia" <?= $item['status'] === 'Tersedia' ? 'selected' : '' ?>>Tersedia</option>
                                        <option value="Habis" <?= $item['status'] === 'Habis' ? 'selected' : '' ?>>Habis</option>
                                        <option value="Dalam Pemesanan" <?= $item['status'] === 'Dalam Pemesanan' ? 'selected' : '' ?>>Dalam Pemesanan</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-actions">
                                <button type="submit" name="submit_update" class="btn-submit">
                                    <i class="fas fa-save"></i> Update Data
                                </button>
                                <a href="?action=inventory" class="btn-cancel">
                                    <i class="fas fa-times"></i> Batal
                                </a>
                            </div>
                        </form>
                    </div>
                    <?php endif; ?>
                    
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

</body>
</html>